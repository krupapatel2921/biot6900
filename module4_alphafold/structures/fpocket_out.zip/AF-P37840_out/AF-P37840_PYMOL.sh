#!/bin/bash
pymol AF-P37840.pml
