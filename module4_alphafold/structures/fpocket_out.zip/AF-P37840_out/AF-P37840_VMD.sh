#!/bin/bash
vmd AF-P37840_out.pdb -e AF-P37840.tcl
