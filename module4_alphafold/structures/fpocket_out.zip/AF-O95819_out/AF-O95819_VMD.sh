#!/bin/bash
vmd AF-O95819_out.pdb -e AF-O95819.tcl
