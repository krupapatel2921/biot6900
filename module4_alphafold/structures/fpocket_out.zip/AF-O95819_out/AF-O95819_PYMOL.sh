#!/bin/bash
pymol AF-O95819.pml
